<?php
/* This file is part of a copyrighted work; it is distributed with NO WARRANTY.
 * See the file COPYRIGHT.html for more details.
 */
 
  require_once("../shared/common.php");
  $tab = "home";
  $nav = "";
  include("../shared/header.php");

?>
This function is not available in the demo version of OpenBiblio
in order to limit the demo database size and to keep the data
presentable.

<?php
  include("../shared/footer.php");
  exit();
?>
