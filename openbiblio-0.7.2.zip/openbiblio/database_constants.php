<?php
/*********************************************************************************
 *
 *                           A T T E N T I O N !
 *
 *  ||  Please modify the following database connection variables to match  ||
 *  \/  the MySQL database and user that you have created for OpenBiblio.   \/
 *********************************************************************************
 */
define("OBIB_HOST",     "localhost");
define("OBIB_DATABASE", "OpenBiblio");
define("OBIB_USERNAME", "your OpenBiblio username goes here");
define("OBIB_PWD",      "your OpenBiblio password goes here");
/*********************************************************************************
 *  /\                                                                      /\
 *  ||                                                                      ||
 *********************************************************************************
 */
?>
