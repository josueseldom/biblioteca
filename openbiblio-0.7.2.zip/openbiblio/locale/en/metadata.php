<?php
/* This file is part of a copyrighted work; it is distributed with NO WARRANTY.
 * See the file COPYRIGHT.html for more details.
 */
 
#****************************************************************************
#*  Translation Metadata
#****************************************************************************
$lang_metadata = array(
   "locale_description" => "English"
);
?>
